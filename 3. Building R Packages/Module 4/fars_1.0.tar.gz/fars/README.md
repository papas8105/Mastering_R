# fars Package

<!-- badges: start -->
[![R-CMD-check](https://github.com/papas8105/Mastering_R/workflows/R-CMD-check/badge.svg)](https://github.com/papas8105/Mastering_R/actions)
<!-- badges: end -->

## Installation

You can install the development version of Highway.Fatality.Census.Project from 
[GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("papas8105/fars")
```
